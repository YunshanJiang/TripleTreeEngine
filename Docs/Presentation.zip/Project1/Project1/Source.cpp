#include <iostream>

using namespace std;


//calculate factorial of n
int CalculateFactorial(int n) {

	if (n == 1)
	{
		return 1;
	}

	return n * CalculateFactorial(n - 1);  // Recurision
}


//calculate the number of trailing zero in n!
//Method 1
int SolutionOne(int n) {

	int factorial = CalculateFactorial(n); //Calculate the result of n! 
	int count = 0;
	int reminder = 0;

	while (reminder == 0)
	{
		reminder = factorial % 10;

		//If the reminder is zero, it represent there is one zero behind the factorial number and we need loop again
		if (reminder == 0)
		{
			count++;
			factorial /= 10; //Set the factorial number to ther reminder of it devided by 10
		}
	}
	return count;
}

//Method 2
int SolutionTwo(int n) {

	int count = 0;

	for (int i = 5; n / i >= 1; i *= 5) {
		count += n / i;
	}

	return count;
}

int main() {

	int num = 10;

	cout << "Solution one: There are " << SolutionOne(num) << " trailing zero" << endl;
	cout << "Solution two: There are " << SolutionTwo(num) << " trailing zero" << endl;
	cout << endl;

	system("Pause");
}